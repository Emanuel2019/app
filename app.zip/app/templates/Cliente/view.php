<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Cliente $cliente
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Cliente'), ['action' => 'edit', $cliente->cliente_id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Cliente'), ['action' => 'delete', $cliente->cliente_id], ['confirm' => __('Are you sure you want to delete # {0}?', $cliente->cliente_id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Cliente'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Cliente'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="cliente view content">
            <h3><?= h($cliente->cliente_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Nome') ?></th>
                    <td><?= h($cliente->nome) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cnpj') ?></th>
                    <td><?= h($cliente->cnpj) ?></td>
                </tr>
                <tr>
                    <th><?= __('Telefone') ?></th>
                    <td><?= h($cliente->telefone) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cliente Id') ?></th>
                    <td><?= $this->Number->format($cliente->cliente_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Data Nasc') ?></th>
                    <td><?= h($cliente->data_nasc) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
