<h1>Login</h1>
<div class="row">
<?= $this->Form->create() ?>
<div class="form-control col-md-6">
<?= $this->Form->input('email') ?>
</div>
<div class="form-control col-md-6">
<?= $this->Form->input('password') ?>
</div>
<?= $this->Form->button('Login') ?>
<?= $this->Form->end() ?>
</div>