<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ClienteFixture
 */
class ClienteFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'cliente';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'cliente_id' => 1,
                'nome' => 'Lorem ipsum dolor sit amet',
                'data_nasc' => '2021-12-08',
                'cnpj' => 'Lorem ipsum dolor ',
                'telefone' => 'Lorem ipsum dolor ',
            ],
        ];
        parent::init();
    }
}
